--------------------------------------------------------
         Richards Custom SCOM MP Tutorial
--------------------------------------------------------
This is just one of the many posts I have created in a series called 
�Custom Management Pack (MP) development for SCOM�.

These files are for example use only and should not be used in a 
production environment.

For more information and the full series please visit:
	http://www.rn.co.za/html/

Feel free to leave comments / crits for me :)