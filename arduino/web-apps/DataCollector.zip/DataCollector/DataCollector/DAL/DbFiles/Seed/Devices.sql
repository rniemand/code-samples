﻿INSERT INTO 'Devices'
	('Deleted', 'Enabled', 'DeviceName', 'DeviceKey')
VALUES
	(0, 1, 'test-device', '0E97314A-8921-499F-BDEB-585276EB3020')
