﻿INSERT INTO 'Temperature'
	('DeviceId', 'Temperature', 'Humidity', 'HeatIndex', 'TimeLoggedUtc')
VALUES
	(@DeviceId, @Temperature, @Humidity, @HeatIndex, @TimeLoggedUtc)