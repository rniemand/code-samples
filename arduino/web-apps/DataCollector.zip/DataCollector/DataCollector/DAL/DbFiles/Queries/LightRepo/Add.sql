﻿INSERT INTO 'Light'
	('DeviceId', 'LightReading', 'TimeLoggedUtc')
VALUES
	(@DeviceId, @Ldr, @TimeLoggedUtc)